﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_OOP6_LastUpdate
{
    internal class Order
    {
        public int Id {  get; set; }
        public string CustomerName {  get; set; }
        public double TotalPrice { get; set; }
        public DateTime OrderDate {  get; set; }
        public bool IsDelivered {  get; set; }

        public Order(int id, string customerName, double totalPrice, DateTime orderDate, bool isDelivered)
        {
            Id = id;
            CustomerName = customerName;
            TotalPrice = totalPrice;
            OrderDate = orderDate;
            IsDelivered = isDelivered;
        }
        public override string ToString()
        {
            return $"Order ID: {Id}, Customer: {CustomerName}, Price: {TotalPrice}, Date: {OrderDate:yyyy-MM-dd}, Delivered: {IsDelivered}";
        }

    }
}
