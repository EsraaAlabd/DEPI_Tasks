﻿using System.Collections;
using System.Security.AccessControl;

namespace Task_OOP6_LastUpdate
{

    //Delegate
    delegate bool Delegate1<T>(T order);

    internal class Program
    {
        static void Main(string[] args)
        {
            //order date
            DateTime d1 = new DateTime(2026, 2, 27);
            DateTime d2 = new DateTime(2025, 10, 18);
            DateTime d3 = new DateTime(2025, 12, 22);
            DateTime d4 = new DateTime(2025, 1, 1);

            //Array of Orders information
            Order[] orders =
            {
            new Order(1, "Alice", 1205.50, d1, true),
            new Order(2, "Bob", 75.00, d1, false),
            new Order(3, "Charlie", 200.00, d2, true),
            new Order(4, "Diana", 1299.99, d1, false),
            new Order(5, "Ethan", 150.25, d3, true),
            new Order(6, "Fatima", 80.00, d4, false),
            new Order(7, "George", 300.10, d4, true),
            new Order(8, "Hana", 45.75, d1, false),
            new Order(9, "Ibrahim", 220.00, d2, true),
            new Order(10, "Julia", 60.00, d3, false),
            new Order(11, "Khalid", 5100.00, d3, true),
            new Order(12, "Lina", 35.50, d4, false),
            new Order(13, "Mohamed", 410.00, d1, true),
            new Order(14, "Nora", 95.00, d2, false),
            new Order(15, "Omar", 250.75, d1, true),
            new Order(16, "Paula", 130.00, d3, false),
            new Order(17, "Qasim", 175.25, d3, true),
            new Order(18, "Rania", 1088.00, d1, false),
            new Order(19, "Samir", 320.40, d2, true),
            new Order(20, "Tina", 55.00, d4, false)
            };


            //Options
            Console.WriteLine("================================================Filtration Types ================================================");
            Console.WriteLine("1 is for filtration based on Customer Name ");
            Console.WriteLine("2 is for filtration based on IsDelivery ");
            Console.WriteLine("3 is for filtration based on  Total price of order ");
            Console.WriteLine("4 is for filtration based on befor a specific date  ");
            Console.WriteLine("5 is for filtration based on after a specific date ");
            Console.WriteLine("==================================================================================================================");
            Console.Write("Enter the number for the type of filtration you want : ");
            string input = Console.ReadLine();
            int option = int.Parse(input);

            switch (option)
            {
                case 1:
                    Filter(orders, CustomerName);
                    break;
                case 2:
                    Filter(orders, IsDelivered);
                    break;
                case 3:
                    Filter(orders, TotalPrice);
                    break;

            }
            
        }

        static bool IsDelivered(Order order)
        {
            if (order.IsDelivered)
                return true;
            return false;
        }
        static bool CustomerName(Order order)
        {
            Console.WriteLine("Enter the customer name ");
            string name = Console.ReadLine();
            return order.CustomerName.StartsWith(name);
        }
        static bool TotalPrice(Order order)
        {
            if (order.TotalPrice > 1000)
                return true;
            return false;
        }
        static bool BeforSpecificDate(Order order, DateTime d)
        {
            if (order.OrderDate < d) return true;
            return false;
        }
        static bool AfterSpecificDate(Order order, DateTime d)
        {
            if (order.OrderDate > d) return true;
            return false;
        }
        static void Filter<T>(IEnumerable<T> arr, Delegate1<T> del)
        {
            foreach (var i in arr)
            {
                if (del(i))
                    Console.WriteLine(i);
            }

        }

    }
}













