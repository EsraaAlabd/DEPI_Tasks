﻿using System.Security.Cryptography.X509Certificates;

namespace LINQtoObject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            


            //extension method syntax
            var books = SampleData.Books;
            var subjects = SampleData.Subjects;
            //========================================Query 1 =========================
            //var query1 = from b in books
            //             select new { b.Title, b.Isbn };
            //foreach ( var b in query1 )
            //{
            //    Console.WriteLine(b);
            //}
            //========================================Query 2 =========================
            //var query2 = books.Where(b => b.Price >= 20).Select(b => b);
            //foreach (var b in query2)
            //{
            //    Console.WriteLine(b);

            //}
            //========================================Query 3 =========================
            //var query3 = books.Select(x => new { x.Title, x.Publisher });
            //foreach (var b in query3)
            //{
            //    Console.WriteLine(b);
            //}
            //var query3_m2= from b in books
            //               select new { b.Title, b.Publisher };
            //foreach (var b in query3_m2)
            //{
            //    Console.WriteLine(b);
            //}
            //========================================Query 4 =========================
            //var query4 = books.Where(b => b.Price > 20).Select(b => b).Count();
            //Console.WriteLine(query4);
            //========================================Query 5 =========================
            //var query5 = books.OrderBy(b => b.Subject).ThenByDescending(b => b.Price).Select(b => new { b.Title, b.Price, b.Subject });
            //var Result = query5.ToList();
            //foreach (var b in Result)
            //{
            //    Console.WriteLine(b);
            //}
            //=========================================some thing wrong 
            //========================================Query 6 =========================
            //========================================Query 7 =========================

            //var query7 = from b in GetBooks()
            //             select (b => new {b.Title , b.Price})
            //foreach (var b in query7)
            //{
            //    Console.WriteLine(b);
            //}
            //========================================Query 8 =========================
            
        }

    }
}
