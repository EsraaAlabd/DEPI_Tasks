﻿
namespace Task.OOP5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            FullTime f = new FullTime(1, "Esraa", "FullTime",200, 142.55);
            PartTime p = new PartTime(2, "Rewan", "PartTime",0, 3.5);
            Manager m=new Manager(3,"Nora","MNGR",250,142.55,140.45);
            HR h = new HR(4, "Menna", "HR",270, 198);

            List<IReportable> list = new List<IReportable>();
            list.Add(new Manager(12, "Mariam", "MNGR",250, 1123, 183.45));
            list.Add((HR)h);

            f.Print();
            p.Print();
            m.Print();
            h.Print();

            //method in program.cs print => can print any type with print method
            //i think any type refer to use generic 
        }
    }
}
