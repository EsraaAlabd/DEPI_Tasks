﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task.OOP5
{
    internal class Employee
    {
         protected int Id { get; set; }
         protected string Name { get; set; }
         protected string Title { get; set; }
         double Salary { get; } 
        public Employee(int id, string name, string title,double salary)
        {
            Id = id;   
            Name = name;
            Title = title;
            Salary = salary;
        }

        public virtual double CalaSalary()
        {
            return Salary;
        }

        public virtual void Print()
        {
            Console.WriteLine($"Id : {Id} , Name : {Name} , Title : {Title} , Salary : {CalaSalary()}");
        }
    }
}
