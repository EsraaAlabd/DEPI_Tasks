﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task.OOP5
{
    internal class PartTime : Employee
    {
        int HourRate = 25;
        double Hours { get; }
        public PartTime(int id, string name, string title, double salary, double hours) : base(id, name, title,salary)
        {
            Hours = hours;
        }

        public override double CalaSalary()
        {
            return base.CalaSalary() + (HourRate* Hours);
        }
        public override void Print()
        {
            Console.WriteLine($"Id : {Id} , Name : {Name} , Title : {Title} , Salary : {CalaSalary()} , Hours : {Hours}");
        }
    }
}
