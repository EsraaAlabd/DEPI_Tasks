﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task.OOP5
{
    internal interface IReportable
    {
        void CreateReport() { }
    }
}
