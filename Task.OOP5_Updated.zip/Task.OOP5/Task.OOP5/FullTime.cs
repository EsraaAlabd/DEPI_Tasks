﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task.OOP5
{
    internal class FullTime : Employee , IPrintable
    {
        double OvertimeSalary {  get; }
        public FullTime (int id, string name,string title, double salary,double overtimeSalary) :base(id,name,title,salary)
        {
            OvertimeSalary = overtimeSalary;
        }
        public override double CalaSalary()
        {
            return base.CalaSalary() + OvertimeSalary;
        }

        public override void Print()
        {
            Console.WriteLine($"Id : {Id} , Name : {Name} , Title : {Title} , Salary : {CalaSalary()} , OverTime : {OvertimeSalary}");
        }
    }
}
