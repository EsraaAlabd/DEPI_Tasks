﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task.OOP5
{
    internal class Manager : Employee , IReportable , IPrintable
    {
        double OvertimeSalary { get; }
        double SalaryBonus {  get; }
        public Manager(int id, string name, string title, double salary, double overtimeSalary,double salarybonus) : base(id, name, title,salary)
        {
            OvertimeSalary = overtimeSalary;
            SalaryBonus = salarybonus;
        }
        public override double CalaSalary()
        {
            return base.CalaSalary() + OvertimeSalary+ SalaryBonus;
        }
        public override void Print()
        {
            Console.WriteLine($"Id : {Id} , Name : {Name} , Title : {Title} , Salary : {CalaSalary()} , OverTime : {OvertimeSalary} , SalaryBonus : {SalaryBonus}");
        }
        void CreateReport()
        {
            Console.WriteLine($"This report created by the manager with Id : {Id} and Name : {Name}");
        }
    }
}
